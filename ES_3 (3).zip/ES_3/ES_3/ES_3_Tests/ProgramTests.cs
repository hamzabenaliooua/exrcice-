﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ES_3;

namespace ES_3_Tests
{
    [TestClass]
    public class ProgramTests
    {
        private const float Epsilon = 0.005f; // pour comparer les résultats au sou près

        [TestMethod]
        public void CalculerDeduction_ItemsNegative_ThrowsArgumentException()
        {
            // BVA : Test pour une valeur limite inférieure invalide (itemsAchetes < 0)
            Assert.ThrowsException<System.ArgumentException>(() => Program.CalculerDeduction(-1));
        }

        [TestMethod]
        public void CalculerDeduction_ItemsZero_ReturnsZeroPercent()
        {
            // BVA : Test pour la limite minimale valide (0 ≤ itemsAchetes < 999)
            float rabais = Program.CalculerDeduction(0);
            Assert.AreEqual(0f, rabais, Epsilon);
        }

        [TestMethod]
        public void CalculerDeduction_Items1000_Returns5Percent()
        {
            // BVA : Test pour une valeur limite (999 ≤ itemsAchetes < 1999)
            float rabais = Program.CalculerDeduction(1000);
            Assert.AreEqual(0.05f, rabais, Epsilon);
        }

        [TestMethod]
        public void CalculerDeduction_Items2000_Returns10Percent()
        {
            // EP : Test pour une valeur représentative d'une partition (1999 ≤ itemsAchetes < 3999)
            float rabais = Program.CalculerDeduction(2000);
            Assert.AreEqual(0.10f, rabais, Epsilon);
        }

        [TestMethod]
        public void CalculerDeduction_Items4000_Returns15Percent()
        {
            // EP : Test pour une valeur représentative d'une partition (3999 ≤ itemsAchetes < 5999)
            float rabais = Program.CalculerDeduction(4000);
            Assert.AreEqual(0.15f, rabais, Epsilon);
        }

        [TestMethod]
        public void CalculerDeduction_Items6000_Returns20Percent()
        {
            // EP : Test pour une valeur représentative d'une partition (5999 ≤ itemsAchetes < 7999)
            float rabais = Program.CalculerDeduction(6000);
            Assert.AreEqual(0.20f, rabais, Epsilon);
        }

        [TestMethod]
        public void CalculerDeduction_Items8000_Returns25Percent()
        {
            // EP : Test pour une valeur représentative d'une partition (7999 ≤ itemsAchetes < 9999)
            float rabais = Program.CalculerDeduction(8000);
            Assert.AreEqual(0.25f, rabais, Epsilon);
        }

        [TestMethod]
        public void CalculerDeduction_Items10000_Returns30Percent()
        {
            // BVA : Test pour une valeur limite (9999 ≤ itemsAchetes < 12000)
            float rabais = Program.CalculerDeduction(10000);
            Assert.AreEqual(0.30f, rabais, Epsilon);
        }

        [TestMethod]
        public void CalculerDeduction_Items12000_ThrowsArgumentException()
        {
            // BVA : Test pour une valeur limite supérieure invalide (itemsAchetes ≥ 12000)
            Assert.ThrowsException<System.ArgumentException>(() => Program.CalculerDeduction(12000));
        }
    }
}
