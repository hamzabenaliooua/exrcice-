﻿//-----------------------------------------------------------------------
// <copyright file="Program.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace ES_3
{
    using System;

    /// <summary>
    /// Classe implantant un programme console de génération de facture pour l'achat d'un
    /// nombre donné d'un même item, à prix unitaire donnée, en applicant des rabais de
    /// vente.
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Fonction déterminant le rabais applicable (en %) à un achat selon le nombre d'items
        /// achetés.
        /// </summary>
        /// <param name="itemsAchetés">Nombre d'items achetés.</param>
        /// <returns>Le % de rabais applicable à l'achat de ces items.</returns>
        public static float CalculerDeduction(int itemsAchetes)
        {
            // Valider le nombre d'items fourni
            if (itemsAchetes < 0)
            {
                throw new System.ArgumentException("Le nombre d'items ne peut être négatif");
            }

            // Calcul de l'amortissement des items selon la quantité achetée et les stocks disponibles.
            double amortissement = Math.Sqrt(itemsAchetes);

            // Valider l'amortissement selon les stocks disponibles.
            if (amortissement > 109.54451150103323)
            {
                throw new System.ArgumentException("Le nombre d'items est excessif");
            }

            // Calculer le rabais à appliquer selon l'amortissement
            float rabais = 0f;
            if (amortissement >= 99.99499987499375)
            {
                rabais = 0.30f;
            }
            else if (amortissement >= 89.4371287553441)
            {
                rabais = 0.25f;
            }
            else if (amortissement >= 77.45321168292507)
            {
                rabais = 0.20f;
            }
            else if (amortissement >= 63.245553203367585)
            {
                rabais = 0.15f;
            }
            else if (amortissement >= 44.710177812216315)
            {
                rabais = 0.10f;
            }
            else if (amortissement >= 31.606961258558215)
            {
                rabais = 0.05f;
            }

            return rabais;
        }

        /// <summary>
        /// Programme principal calculant la facture d'achat d'un nombre d'item selon le prix unitaire
        /// et le rabais applicable.
        /// </summary>
        /// <param name="args">Arguments de ligne de commande.</param>
        public static void Main(string[] args)
        {
            // Obtenir le nombre d'items achetés
            string input = string.Empty;
            int items = 0;
            do
            {
                Console.Write("\nNombre d'items achetés ? ");
                input = Console.ReadLine();
            }
            while (!int.TryParse(input, out items));

            // Obtenir le prix unitaire
            float prixUnitaire = 0f;
            do
            {
                Console.Write("Prix unitaire en $ ? ");
                input = Console.ReadLine();
            }
            while (!float.TryParse(input, out prixUnitaire));

            // Calculer les éléments de la facture
            float totalAvantRabais = items * prixUnitaire;
            float déductionApplicable = CalculerDeduction(items);
            float rabais = totalAvantRabais * déductionApplicable;
            float totalAprèsRabais = totalAvantRabais - rabais;

            // Afficher la facture
            Console.WriteLine("\n\nTotal des achats avant rabais = " + FormaterSomme(totalAvantRabais));

            int rabaisPourcentage = (int)(déductionApplicable * 100);
            Console.WriteLine("Rabais applicables            = " + rabaisPourcentage + "% (" + FormaterSomme(rabais) + ")");

            Console.WriteLine("Total des achats après rabais = " + FormaterSomme(totalAprèsRabais));
        }

        /// <summary>
        /// Retourne sous forme de chaîne la somme d'argent fournie. Pafr exemple, pour
        /// somnme = 3.57, la fonction retourne "3,57$".
        /// </summary>
        /// <param name="somme">Montant d'argent à fomater en chaîne.</param>
        /// <returns>La somme donnée convertie en chaîne formatée sous forme de montant d'argent.</returns>
        private static string FormaterSomme(float somme)
        {
            decimal décimal = Convert.ToDecimal(somme);
            return décimal.ToString("C");
        }
    }
}
