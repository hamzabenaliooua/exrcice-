﻿using AuteurEFC.Models;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AuteurEFC
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // Constructeur de la fenêtre principale
        public MainWindow()
        {
            InitializeComponent();  // Initialisation des composants de la fenêtre XAML.
            LoadAuthors();  // Chargement des auteurs dans le DataGrid au démarrage.
            LoadBooks();  // Chargement des livres dans le DataGrid au démarrage.
        }

        // Gestionnaire d'événement pour le bouton "Ajouter un Auteur"
        private void btnAddAuthor_Click(object sender, RoutedEventArgs e)
        {
            using(AuteurDBContext context = new AuteurDBContext())
            {
             
                Author auteurExiste = context.Authors.Where(a=>a.Name.Equals(txtName.Text)).FirstOrDefault();

                if (auteurExiste == null)
                {
                    auteurExiste =  new Author { Name = txtName.Text, Biography = txtBiblio.Text};
                    
                    context.Authors.Add(auteurExiste);  // Ajouter l'auteur à la base de données.
                    context.SaveChanges();  // Sauvegarder les modifications dans la base de données.
                    LoadAuthors();  // Recharger les auteurs dans le DataGrid après l'ajout.
                    tbStatus.Text = "Auteur ajouté avec succès.";
                }
                else
                {
                    tbStatus.Text = "Cet auteur existe déjà.";

                }

                


            }

        }

        // Gestionnaire d'événement pour le bouton "Mettre à jour un Auteur"
        private void btnUpdateAuthor_Click(object sender, RoutedEventArgs e)
        {
            using (AuteurDBContext context = new AuteurDBContext())
            {

                Author auteurExiste = context.Authors.Where(a => a.Name.Equals(txtName.Text)).FirstOrDefault();

                if (auteurExiste == null)
                {
                    tbStatus.Text = "Cet auteur n'existe pas.";
                }
                else
                {
                    auteurExiste.Name = txtName.Text;
                    auteurExiste.Biography = txtBiblio.Text;

                    context.SaveChanges();  // Sauvegarder les modifications dans la base de données.
                    LoadAuthors();  // Recharger les auteurs dans le DataGrid après l'ajout.
                    tbStatus.Text = "Cet auteurest mis a jours!.";

                }

            }

        }

        // Gestionnaire d'événement pour le bouton "Supprimer un Auteur"
        private void btnDeleteAuthor_Click(object sender, RoutedEventArgs e)
        {
            // Cette méthode est vide pour l'instant, elle pourrait être utilisée pour supprimer un auteur.

            using(AuteurDBContext context = new AuteurDBContext())
            {
             Author AuteurExiste = context.Authors.Where(
                 a=> a.Name.Equals(txtName.Text)).FirstOrDefault();

                if (AuteurExiste == null)
                {
                  
                    tbStatus.Text = "Cet auteur n'existe pas.";
                }
                else
                {
                    Book Livre = context.Books.Where(l => l.AuthorId.Equals(AuteurExiste.AuthorId))
                      .FirstOrDefault();
                    
                        if(Livre != null)
                        {
                            tbStatus.Text = "Cet auteur a des livres associes.";
                            return;
                        }
                        else
                        {
                            context.Authors.Remove(AuteurExiste);
                            context.SaveChanges();
                            LoadAuthors();
                            tbStatus.Text = "Auteur retire de la BDD!";

                        }
                    
                }

            }
        }

        // Méthode pour charger les auteurs dans le DataGrid
        public void LoadAuthors()
        {
            using (AuteurDBContext context = new AuteurDBContext())
            {
                var Auteurs = context.Authors.ToList();  // Récupérer la liste des auteurs depuis la base de données.
                dgAuthors.ItemsSource= Auteurs;  // Afficher la liste des auteurs dans le DataGrid.


            }

        }

        // Méthode pour charger les livres dans le DataGrid
        public void LoadBooks()
        {
            using (AuteurDBContext context = new AuteurDBContext())
            {
                var Livres = context.Books.ToList();  // Récupérer la liste des auteurs depuis la base de données.
                dgBook.ItemsSource = Livres;  // Afficher la liste des auteurs dans le DataGrid.


            }

        }

        // Gestionnaire d'événement pour le bouton "Ajouter un Livre"
        private void btnAddBook_Click(object sender, RoutedEventArgs e)
        {
            using(AuteurDBContext context = new AuteurDBContext())
            {

                Author AuteurExiste = context.Authors.Where(
                    a => a.AuthorId.Equals(int.Parse(txtAuthorId.Text))).FirstOrDefault();

                if (AuteurExiste !=null)
                {
                    // si le livre existe.
                    Book LivreExiste= context.Books.Where(
                    livre => livre.Title.Equals(txtTitle.Text)).FirstOrDefault();

                    if (LivreExiste == null)
                    {
                        LivreExiste = new Book
                        {
                            Title = txtTitle.Text,
                            Genre = txtGenre.Text,
                            AuthorId = int.Parse(txtAuthorId.Text)
                        };

                        context .Books.Add(LivreExiste);  // Ajouter le livre à la base de données.
                        context.SaveChanges();  // Sauvegarder les modifications dans la base de données.
                        LoadBooks();  // Recharger les livres dans le DataGrid après l'ajout.

                        tbStatus.Text = "Livre ajouté avec succès.";
                    }
                    else
                    {
                        tbStatus.Text = "Ce livre existe déjà.";

                    }
                            


                }
                else
                {
                    tbStatus.Text = "Cet auteur n'existe pas";

                }
            }

        }

        // Gestionnaire d'événement pour le bouton "Mettre à jour un Livre"
        private void btnUpdateBook_Click(object sender, RoutedEventArgs e)
        {

            using (AuteurDBContext context = new AuteurDBContext())
            {
                Book Livre = context.Books.Where(
                    l => l.Title.Equals(txtTitle.Text)
                    ).FirstOrDefault();

                if (Livre != null)
                {
                    Author auteur = context.Authors.Where(

                        a=> a.AuthorId.Equals(int.Parse(txtAuthorId.Text)

                        )).FirstOrDefault () ;


                    if (auteur == null)
                    {
                        tbStatus.Text = "Auteur n'existe pas";
                        return;
                    }
                    else
                    {
                        Livre.Title = txtTitle.Text;
                        Livre.Genre = txtGenre.Text;
                        Livre.AuthorId = int.Parse(txtAuthorId.Text);
                        context.SaveChanges();  // Sauvegarder les modifications dans la base de données.
                        LoadBooks();  // Recharger les livres dans le DataGrid après l'ajout.
                        tbStatus.Text = "Livre mis à jour avec succès.";

                    }



                }
                else
                {
                        tbStatus.Text = "Ce livre n'existe pas.";
                }
            }
        }

        // Gestionnaire d'événement pour le bouton "Supprimer un Livre"
        private void btnDeleteBook_Click(object sender, RoutedEventArgs e)
        {

          using (AuteurDBContext context = new AuteurDBContext())
            {
                Book livreExiste = context.Books.Where(l=>l.Title.Equals(txtTitle.Text)).FirstOrDefault();

                if ( livreExiste != null)
                {
                    context.Books.Remove(livreExiste);
                    context.SaveChanges();
                    LoadBooks();
                    tbStatus.Text = "Livre retire de la BDD!";

                }
                else
                    tbStatus.Text = "Ce livre n'existe pas.";

            }

        }

        // Gestionnaire d'événement pour consulter les livres d'un auteur
        private void btnConsulter(object sender, RoutedEventArgs e)
        {

            using (AuteurDBContext context = new AuteurDBContext())
            {
                Author AuteurAConsulter = context.Authors.Where(
                  a => a.Name.Equals(txtAuteurConsult.Text)
                    ).FirstOrDefault();

                if (AuteurAConsulter != null)
                {

                    var requete = context.Books.AsQueryable();

                    requete = requete.Where(l => l.AuthorId.Equals(AuteurAConsulter.AuthorId));

                    dgBookConsult.ItemsSource = requete.ToList();


                }
                else
                {
                    dgBookConsult.ItemsSource = null;
                }

            }


        }
    }
}