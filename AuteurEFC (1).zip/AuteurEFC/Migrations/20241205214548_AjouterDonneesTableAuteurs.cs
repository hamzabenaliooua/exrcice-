﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AuteurEFC.Migrations
{
    /// <inheritdoc />
    public partial class AjouterDonneesTableAuteurs : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
            table: "Authors",
            columns: new[] { "Name", "Biography", },
            values: new object[,]
                {
      {  "J.K. Rowling", "Auteur britannique, connue pour la série Harry Potter." },
      { "George R.R. Martin","Auteur américain, connu pour la série Le Trône de fer." },
      { "J.R.R. Tolkien",  "Écrivain et philologue britannique, connu pour Le Seigneur des anneaux." },
      { "Agatha Christie", "Romancière britannique, célèbre pour ses romans policiers." },
      { "Isaac Asimov",  "Auteur et biochimiste américain, connu pour ses œuvres de science-fiction." },
      { "Stephen King", "Auteur américain, maître de l'horreur et du fantastique." },
      { "Jane Austen",  "Romancière anglaise, célèbre pour ses romans sur la vie des classes supérieures anglaises." },
      { "Mark Twain",  "Auteur américain, connu pour ses œuvres classiques comme Les Aventures de Tom Sawyer." },
      { "Haruki Murakami",  "Auteur japonais, dont les œuvres explorent des thèmes de solitude et de surréalisme." },
      { "Margaret Atwood",  "Romancière canadienne, connue pour ses écrits de science-fiction et féministes." }
        });

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DELETE FROM Authors");
        }
    }
}
