﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AuteurEFC.Migrations
{
    /// <inheritdoc />
    public partial class AjouterDonneesTableLivre : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
            table: "Books",
            columns: new[] { "Title", "Genre", "AuthorId" },
            values: new object[,]
            {


              {"Harry Potter à l'école des sorciers", "Fantasy", 1 },
              {"Harry Potter et la Chambre des secrets", "Fantasy", 1 },
              {"Le Trône de fer", "Fantasy", 2 },
               {"A Game of Thrones", "Fantasy", 2 },
               {"Le Seigneur des anneaux",  "Fantasy",  3 },
               {"Les Aventures de Hercule Poirot", "Mystery", 4 },
               {"Murder on the Orient Express",  "Mystery", 4 },
               {"Fondation", "Science-fiction", 5 },
               {"Shining", "Horror", 6 },
               {"Orgueil et Préjugés", "Romance", 7 }
            });


        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("Delete from Books");
        }
    }
}
