﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuteurEFC.Models
{
    public class Author
    {

        [Key]
        public int AuthorId { get; set; }  // Primary Key
        public string Name { get; set; }
        public string Biography { get; set; }
        // Navigation property: one-to-many relationship with Book
        public ICollection<Book> Books { get; set; }

    }
}
