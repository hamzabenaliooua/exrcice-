﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuteurEFC.Models
{
    public class Book
    {
        [Key]
        public int BookId { get; set; }  // Primary Key
        public string Title { get; set; }
        public string Genre { get; set; }
        // Foreign Key: One book has one author
        public int AuthorId { get; set; }
        // Navigation property: each book has one author
        public Author Author { get; set; }

    }
}
