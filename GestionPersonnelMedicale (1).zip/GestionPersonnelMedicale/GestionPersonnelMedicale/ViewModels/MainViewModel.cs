﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionPersonnelMedicale.ViewModels
{
    public class MainViewModel
    {
        public DepartementViewModel DepartementViewModel { get; set; }
        public InfirmierViewModel InfirmierViewModel { get; set; }

        public MainViewModel()
        {
            DepartementViewModel = new DepartementViewModel();
            InfirmierViewModel = new InfirmierViewModel();
        }
    }
}

