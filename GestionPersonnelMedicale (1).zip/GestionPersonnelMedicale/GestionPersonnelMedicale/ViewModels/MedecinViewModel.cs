﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using GestionPersonnelMedicale.Models;
using System.Collections.ObjectModel;

namespace GestionPersonnelMedicale.ViewModels
{
    public class MedecinViewModel
    {
        public ObservableCollection<Medecin> Medecins { get; set; }

        public MedecinViewModel()
        {
            Medecins = new ObservableCollection<Medecin>();
        }

        public void AddMedecin(Medecin medecin)
        {
            Medecins.Add(medecin);
        }
    }
}

