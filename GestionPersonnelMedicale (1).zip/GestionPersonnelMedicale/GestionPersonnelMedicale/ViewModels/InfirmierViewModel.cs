﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using GestionPersonnelMedicale.Models;
using System.Collections.ObjectModel;

namespace GestionPersonnelMedicale.ViewModels
{
    public class InfirmierViewModel
    {
        public ObservableCollection<Infirmier> Infirmiers { get; set; }
        public Infirmier SelectedInfirmier { get; set; }

        public InfirmierViewModel()
        {
            Infirmiers = new ObservableCollection<Infirmier>
            {
                new Infirmier { Nom = "Dupont", Prenom = "Jean", Departement = "Cardiologie", Disponibilite = true },
                new Infirmier { Nom = "Durand", Prenom = "Marie", Departement = "Radiologie", Disponibilite = false }
            };
        }

        public void AddInfirmier(Infirmier infirmier)
        {
            Infirmiers.Add(infirmier);
        }

        public void RemoveInfirmier(Infirmier infirmier)
        {
            Infirmiers.Remove(infirmier);
        }
    }
}

