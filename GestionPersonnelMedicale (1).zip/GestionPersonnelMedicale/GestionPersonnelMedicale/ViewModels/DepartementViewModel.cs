﻿using GestionPersonnelMedicale.Models;
using System.Collections.ObjectModel;

namespace GestionPersonnelMedicale.ViewModels
{
    public class DepartementViewModel
    {
        public ObservableCollection<Departement> Departements { get; set; }
        public Departement SelectedDepartement { get; set; }

        public DepartementViewModel()
        {
            Departements = new ObservableCollection<Departement>
            {
                new Departement { Nom = "Cardiologie", Description = "Département de soins cardiaques" },
                new Departement { Nom = "Radiologie", Description = "Département d'imagerie médicale" }
            };
        }

        public void AddDepartement(Departement departement)
        {
            Departements.Add(departement);
        }

        public void RemoveDepartement(Departement departement)
        {
            Departements.Remove(departement);
        }

        public bool CanDeleteDepartement(Departement departement)
        {
            // Placeholder for checking if the department has associated personnel
            // This logic should be replaced with actual checks against the data source
            bool hasAssociatedPersonnel = CheckIfDepartmentHasPersonnel(departement);

            if (hasAssociatedPersonnel)
            {
                // If the department has associated personnel, it cannot be deleted
                return false;
            }

            return true;
        }

        // Simulated method to check if the department has associated personnel
        private bool CheckIfDepartmentHasPersonnel(Departement departement)
        {
            // Placeholder logic: This should be replaced with real checks
            // For example: Query a database or access a data source
            return false; // Simulates that no personnel are associated with the department
        }
    }
}
