﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionPersonnelMedicale.Models
{
    public class Departement
    {
        public string Nom { get; set; }
        public string Description { get; set; }
    }
}
