﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows;
using GestionPersonnelMedicale.ViewModels;

namespace GestionPersonnelMedicale.Views
{
    public partial class MainWindow : Window
    {
        public MainViewModel ViewModel { get; set; }

        public MainWindow()
        {
            InitializeComponent();

            // Initialize the MainViewModel and set it as the DataContext for the window
            ViewModel = new MainViewModel();
            DataContext = ViewModel;
        }
    }
}

