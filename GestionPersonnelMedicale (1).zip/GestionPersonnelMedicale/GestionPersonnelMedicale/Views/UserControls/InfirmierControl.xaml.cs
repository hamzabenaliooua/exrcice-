﻿using GestionPersonnelMedicale.Models;
using GestionPersonnelMedicale.ViewModels;
using System.Windows;
using System.Windows.Controls;

namespace GestionPersonnelMedicale.Views.UserControls
{
    public partial class InfirmierControl : UserControl
    {
        public InfirmierViewModel ViewModel { get; set; }

        public InfirmierControl()
        {
            InitializeComponent();
            ViewModel = new InfirmierViewModel();
            DataContext = ViewModel;
        }

        private void AddInfirmier_Click(object sender, RoutedEventArgs e)
        {
            // Example of adding a new infirmier
            var newInfirmier = new Infirmier
            {
                Nom = "Nouveau",
                Prenom = "Infirmier",
                Departement = "Général",
                Disponibilite = true
            };
            ViewModel.AddInfirmier(newInfirmier);
        }

        private void EditInfirmier_Click(object sender, RoutedEventArgs e)
        {
            if (ViewModel.SelectedInfirmier != null)
            {
                // Example of editing the selected infirmier
                ViewModel.SelectedInfirmier.Nom = "Modifié";
                ViewModel.SelectedInfirmier.Prenom = "Infirmier";
            }
            else
            {
                MessageBox.Show("Veuillez sélectionner un infirmier à modifier.");
            }
        }

        private void DeleteInfirmier_Click(object sender, RoutedEventArgs e)
        {
            if (ViewModel.SelectedInfirmier != null)
            {
                ViewModel.RemoveInfirmier(ViewModel.SelectedInfirmier);
            }
            else
            {
                MessageBox.Show("Veuillez sélectionner un infirmier à supprimer.");
            }
        }
    }
}
