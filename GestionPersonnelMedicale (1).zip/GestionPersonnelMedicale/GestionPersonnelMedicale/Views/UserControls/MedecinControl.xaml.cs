﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Controls;

namespace GestionPersonnelMedicale.Views.UserControls
{
    public partial class MedecinControl : UserControl
    {
        public MedecinControl()
        {
            InitializeComponent();
        }
    }
}
