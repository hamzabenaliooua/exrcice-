﻿using GestionPersonnelMedicale.Models;
using GestionPersonnelMedicale.ViewModels;
using System.Windows;
using System.Windows.Controls;

namespace GestionPersonnelMedicale.Views.UserControls
{
    public partial class DepartementControl : UserControl
    {
        public DepartementViewModel ViewModel { get; set; }

        public DepartementControl()
        {
            InitializeComponent();
            ViewModel = new DepartementViewModel();
            DataContext = ViewModel;
        }

        private void AddDepartement_Click(object sender, RoutedEventArgs e)
        {
            // Example of adding a new department
            var newDepartement = new Departement
            {
                Nom = "Nouveau Département",
                Description = "Description du département"
            };
            ViewModel.AddDepartement(newDepartement);
        }

        private void EditDepartement_Click(object sender, RoutedEventArgs e)
        {
            if (ViewModel.SelectedDepartement != null)
            {
                // Example of editing the selected department
                ViewModel.SelectedDepartement.Nom = "Département Modifié";
                ViewModel.SelectedDepartement.Description = "Description mise à jour";
            }
            else
            {
                MessageBox.Show("Veuillez sélectionner un département à modifier.");
            }
        }

        private void DeleteDepartement_Click(object sender, RoutedEventArgs e)
        {
            if (ViewModel.SelectedDepartement != null)
            {
                // Verify if the department can be deleted
                if (ViewModel.CanDeleteDepartement(ViewModel.SelectedDepartement))
                {
                    ViewModel.RemoveDepartement(ViewModel.SelectedDepartement);
                }
                else
                {
                    MessageBox.Show("Impossible de supprimer ce département. Assurez-vous qu'il ne contient pas d'infirmiers ou de médecins.");
                }
            }
            else
            {
                MessageBox.Show("Veuillez sélectionner un département à supprimer.");
            }
        }
    }
}
