﻿using System.Windows;
using GestionPersonnelMedicale.ViewModels;

namespace GestionPersonnelMedicale
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainViewModel ViewModel { get; private set; }

        public MainWindow()
        {
            InitializeComponent();

            // Initialize the MainViewModel and set it as the DataContext for the window
            ViewModel = new MainViewModel();
            DataContext = ViewModel;

            // Set window title dynamically
            this.Title = "Gestion du Personnel Médical";
        }
    }
}
