﻿using System;
using System.Collections.Generic;

namespace Exame_UA3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("\nChoisir une option:");
                Console.WriteLine("1. HybridHeapSort");
                Console.WriteLine("2. JourDeVente et ventesSort");
                Console.WriteLine("3. Quitter");
                Console.Write("Choisir votre choix: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        UseHybridHeapSort();
                        break;
                    case "2":
                        UseJourDeVente();
                        break;
                    case "3":
                        Console.WriteLine("Exiting program...");
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }

        static void UseHybridHeapSort()
        {
            int[] tableau = { 10, 15, 20, 5, 7, 2, 25, 17, 8 };
            int seuil = 3; // Threshold for insertion sort

            Console.WriteLine("\nHybridHeapSort:");
            Console.WriteLine("Tableau avant le tri : " + string.Join(", ", tableau));
            HybridHeap.HybridHeapSort(tableau, seuil);
            Console.WriteLine("Tableau après le tri : " + string.Join(", ", tableau));
        }

        static void UseJourDeVente()
        {
            // Define the list of sales days
            List<JourDeVente> joursDeVente = new List<JourDeVente>
            {
                new JourDeVente("2024-12-01", new Dictionary<string, double>
                {
                    { "Article1", 300.00 },
                    { "Article2", 250.00 },
                    { "Article3", 150.00 }
                }),
                new JourDeVente("2024-12-02", new Dictionary<string, double>
                {
                    { "Article1", 100.00 },
                    { "Article2", 200.00 },
                    { "Article3", 250.00 }
                }),
                new JourDeVente("2024-12-03", new Dictionary<string, double>
                {
                    { "Article1", 400.00 },
                    { "Article2", 300.00 },
                    { "Article3", 200.00 }
                })
            };

            // Display the list before sorting
            Console.WriteLine("\nListe avant tri :");
            foreach (var jour in joursDeVente)
            {
                Console.WriteLine(jour);
            }

            // Sort the list in ascending order (croissant) based on total sales
            var joursTriAscendant = new List<JourDeVente>(joursDeVente);
            joursTriAscendant.Sort((a, b) => a.CalculerChiffreAffaires().CompareTo(b.CalculerChiffreAffaires()));

            Console.WriteLine("\nListe triée (croissant) :");
            foreach (var jour in joursTriAscendant)
            {
                Console.WriteLine(jour);
            }

            // Sort the list in descending order (décroissant) based on total sales
            var joursTriDescendant = new List<JourDeVente>(joursDeVente);
            joursTriDescendant.Sort((a, b) => b.CalculerChiffreAffaires().CompareTo(a.CalculerChiffreAffaires()));

            Console.WriteLine("\nListe triée (décroissant) :");
            foreach (var jour in joursTriDescendant)
            {
                Console.WriteLine(jour);
            }
        }
    }
}
