﻿using System;
using System.Collections.Generic;

namespace Exame_UA3
{
    public class JourDeVente
    {
        public string Jour { get; set; }
        public Dictionary<string, double> Ventes { get; set; }

        public JourDeVente(string jour, Dictionary<string, double> ventes)
        {
            Jour = jour;
            Ventes = ventes;
        }

        
        public double CalculerChiffreAffaires()
        {
            double total = 0;
            foreach (var vente in Ventes)
            {
                total += vente.Value;
            }
            return total;
        }

      
        public override string ToString()
        {
            return $"Jour = {Jour}, Chiffre d'affaires total = {CalculerChiffreAffaires():C}";
        }
    }
}
