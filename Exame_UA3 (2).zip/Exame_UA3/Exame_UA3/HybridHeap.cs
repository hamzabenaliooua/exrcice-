﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exame_UA3
{
    using System;

    class HybridHeap
    {
        public static void HybridHeapSort(int[] tableau, int seuil)
        {
            
            ConstruireTasMax(tableau);

            int n = tableau.Length;

            for (int i = n - 1; i > 0; i--)
            {
                Echanger(tableau, 0, i);

                if (i <= seuil)
                {
                    InsertionSort(tableau, 0, i);
                    break;
                }
                else
                {
                   
                    TasMaxify(tableau, 0, i);
                }
            }
        }

        private static void ConstruireTasMax(int[] tableau)
        {
            int n = tableau.Length;

            
            for (int i = (n / 2) - 1; i >= 0; i--)
            {
                TasMaxify(tableau, i, n);
            }
        }

        private static void TasMaxify(int[] tableau, int index, int taille)
        {
            int plusGrand = index;
            int gauche = 2 * index + 1;
            int droite = 2 * index + 2;

            if (gauche < taille && tableau[gauche] > tableau[plusGrand])
            {
                plusGrand = gauche;
            }

            
            if (droite < taille && tableau[droite] > tableau[plusGrand])
            {
                plusGrand = droite;
            }

          
            if (plusGrand != index)
            {
                Echanger(tableau, index, plusGrand);
                TasMaxify(tableau, plusGrand, taille);
            }
        }

        private static void InsertionSort(int[] tableau, int debut, int fin)
        {
            for (int i = debut + 1; i < fin; i++)
            {
                int cle = tableau[i];
                int j = i - 1;

                
                while (j >= debut && tableau[j] > cle)
                {
                    tableau[j + 1] = tableau[j];
                    j--;
                }

                tableau[j + 1] = cle;
            }
        }

        private static void Echanger(int[] tableau, int i, int j)
        {
            int temp = tableau[i];
            tableau[i] = tableau[j];
            tableau[j] = temp;
        }

    }
}
